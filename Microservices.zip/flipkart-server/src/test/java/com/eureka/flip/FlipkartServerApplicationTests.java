package com.eureka.flip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlipkartServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
